package com.mycompany.myapp.mapper;

import com.mycompany.myapp.vo.BoardVO;

public interface BoardMapper {
	void insert(BoardVO vo);
}
