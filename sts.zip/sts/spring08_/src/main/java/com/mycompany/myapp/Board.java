package com.mycompany.myapp;

import java.sql.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Board {

	@Id
	private Integer no;
	private String title;
	private String content;
	private String id;
	private Date postdate;
	private Integer visitcount;
	
	@JsonManagedReference // Comm 전부 불러옴
	@OneToMany(mappedBy = "board", cascade = CascadeType.REMOVE)
	private List<Comm> commentList;
	
}










