package com.mycompany.myapp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CommRepository extends JpaRepository<Comm, Integer> {

}
