package com.mycompany.myapp;

import java.util.Optional;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class CommService {

	private final BoardRepository boardRepository;
	private final CommRepository commRepository;
	
	public void insert(Comm comm, Integer no) {
		Optional<Board> o = boardRepository.findById(no);
		
		comm.setBoard(o.get());
		
		commRepository.save(comm);
	}
	
	public void delete(Integer code) {
		commRepository.deleteById(code);
		
  		// Optional<Comm> comm = commRepository.findById(code); 두 줄로 쓰기
		// commRepository.delete(comm.get());
	}
	
}












