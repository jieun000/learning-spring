package com.mycompany.myapp;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Comm {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer code;		// 댓글 코드
	private String id;			// 작성자 아이디
	private String content;		// 댓글 내용
	
	@JsonBackReference // Json이건 안 불림
	@ManyToOne
	private Board board;		// 댓글 단 게시물
	
}











