package com.mycompany.myapp;

import java.util.Optional;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@RestController
public class CommRESTController {

	private final CommService commService;
	
	@PostMapping("/insert")
	public void insertComm(@ModelAttribute Comm comm, @RequestParam Integer no) {
	
		commService.insert(comm, no);
		
	}
	
		// getMapping도 됨
	@DeleteMapping("/delete/{code}") // 쿼리스트링으로 딜리드 받아서해도 상관없음. 다양하게 해보고자 할 뿐
	public void deleteComm(@PathVariable Integer code) { 
		commService.delete(code);
	}
	// postman: delete http://localhost:8989//delete/6
	
}












