                        // url주소 빼올 때 쓰는 클래스 만듦
const urlSearch = new URLSearchParams(location.search) 
const no = urlSearch.get('no');
let url = "http://localhost:8989/detail?no=" + no;

console.log(no);

window.onload = function() {

    $.get(url).done(function(data) {

        $('.title').text(data.title);
        $('.id').text(data.id);
        $('.content').text(data.content);

        data.commentList.forEach(comment => {

            let form = 
			            `
			            <div class="mb-3 boarder d-flex">
			                <div class="p-2 col-2">${comment.id}</div>
			                <div class="p-2 col-9">${comment.content}</div>
			
			                <button class="btn-cmt-del btn btn-danger col-1" data-code="${comment.code}">x</button>
			            </div>
			            `;
    
            $('.cmt').append(form);

        });
        
    });

};

$('.submit').on('click', function(e){

    e.preventDefault();

    const commInfo = $('.commForm ').serialize();

    console.log(commInfo);
                        
    let id = $('.commForm .form-control').eq(0);
    let content = $('.commForm .form-control').eq(1); 
    
    console.log(id.val());
    console.log(content.val());

    // 서버로 전송( commInfo를 포함하여 )
	$.post("http://localhost:8989/insert?no=" +no, commInfo).done(function(){
        alert('댓글이 작성되었습니다.');

        let form = 
			        `
			        <div class="mb-3 boarder d-flex">
			            <div class="p-2 col-2">${id.val()}</div>
			            <div class="p-2">${content.val()}</div>
			        </div>
			        `;

        $('.cmt').append(form);

        id.val('');
		content.val('');
    });
});


// $('.btn-cmt-del').on('click', function(){
//     alert('이거안됨');
// });
// $(document).on('click', '.btn-cmt-del', function(){
//     alert('이렇게 해야 됨');
// });

//답변 제거
$(document).on('click', '.btn-cmt-del', function(e) {

    let code = e.target.dataset.code;
//    console.log(code);

    if(confirm('정말로 삭제하시겠습니까?')) {
        $.ajax({
            url: "http://localhost:8989/delete/" + code,
            method: "delete",
            success: function() {
                $(e.target).parent().remove(); // 타겟 지움
                alert('삭제가 완료되었습니다.');
            }
        });
    }

});



// 수정?
$(document).on('click', '.btn-cmt-modify', function(e) {

    let form = `
			    <form class="commForm" method="post">
			        <input class="form-control mb-2"  type="text" name="id" placeholder="아이디">
			        <textarea class="form-control mb-2" rows="3" name="content" placeholder="댓글을 작성하세요"></textarea>
			        <button class="submit btn btn-primary">댓글달기</button>
			    </form>
			    `

    e.target.append(form);
    
});