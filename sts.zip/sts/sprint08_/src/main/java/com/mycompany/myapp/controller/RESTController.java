package com.mycompany.myapp.controller;

@RestController
public class RESTController {

}
